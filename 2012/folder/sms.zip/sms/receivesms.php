<?

$a['registrationID']="*****";  /*Your AloAshbei Username*/
$a['password']="*****";   /*Your Aloashbei Password*/
$a['smsPort']="7424";
$a['msgID']="0";

$soap_url='http://localhost/WebService_GP_ADP_BizTalk_SMS_Orchestrations.wsdl';

$soap = new SoapClient($soap_url);

$response=$soap->getReceivedSMS( array ("ReceiveSMSRequest" => $a) );

$msg=$response->ReceiveSMSResponse->msgContent;

$number=$response->ReceiveSMSResponse->senderMSISDN;

while(strcmp($msg,"No new SMS")!=0)
{
	$msgfinal=$msg;
	$a['msgID']=$response->ReceiveSMSResponse->msgID;
	$soap = new SoapClient($soap_url);
	$response=$soap->getReceivedSMS( array ("ReceiveSMSRequest" => $a) );
	$msg=$response->ReceiveSMSResponse->msgContent;
}

echo "Message:".$msgfinal." from ".$number;

?>
