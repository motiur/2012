$(document).ready(function(){

    /* Table zebra classes */
    $('.zebra:odd').addClass('odd');
    $('.zebra:even').addClass('even');

    /* We will lazy load the two heavy images */
    $('body').addClass('body-bg');
    $('#wrap').addClass('wrap-bg');
    
});