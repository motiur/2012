<html><head><title>GrameenPhone</title><script language="JavaScript" type="text/javascript" src="gfx/javascript_util.js"></script><link rel="stylesheet" href="gfx/layout.css" type="text/css"><link rel="stylesheet" href="gfx/style_util.css" type="text/css"><link rel="stylesheet" href="gfx/class.css" type="text/css"><meta http-equiv="CACHE-CONTROL" content="NO-CACHE"></head><body><div id="main">
<div id="header">
<img src="gfx/gp_white.jpg" alt="Grameenphone">
<div id="globalmenu">
<ul>
<li class="first"><a href="http://www.grameenphone.com/index.php?id=1" title="Fast, Free, and Infinitely Flexible" target="_blank">Home</a></li>
</ul>
</div>
<div id="input">
<table border="0" cellspacing="0" cellpadding="0">
<tr>
<td class="menuTD">
<form method="post" action="">
<input type="hidden" name="mid" value="3"><input type="submit" name="Personal Info" value="Personal Info" class="btn" onmouseover="this.className='btn btnhov'" onmouseout="this.className='btn'">

</form>
</td>
<td class="menuTD">
<form method="post" action="">
<input type="hidden" name="mid" value="4"><input type="submit" name="Add New Contact" value="Add New Contact" class="btn" onmouseover="this.className='btn btnhov'" onmouseout="this.className='btn'">
</form>
</td>
<td class="menuTD">
<form method="post" action="">
<input type="hidden" name="mid" value="5"><input type="submit" name="Phone Book" value="Phone Book" class="btn" onmouseover="this.className='btn btnhov'" onmouseout="this.className='btn'">
</form>
</td>
<td class="menuTD">
<form method="post" action="">
<input type="hidden" name="mid" value="6"><input type="submit" name="Send SMS" value="Send SMS" class="btnselect" onmouseover="this.className='btn btnhov'" onmouseout="this.className='btnselect'"></form>
</td>
<td class="menuTD">

<form method="post" action="">
<input type="hidden" name="mid" value="7"><input type="submit" name="SMS History" value="SMS History" class="btn" onmouseover="this.className='btn btnhov'" onmouseout="this.className='btn'"></form>
</td>
<td class="menuTD"><form method="post" action=""><input type="hidden" name="mid" value="8"><input type="submit" name="Logout" value="Logout" class="btn" onmouseover="this.className='btn btnhov'" onclick="javascript:alert('Thank you for using Grameenphone Web SMS Service.')" onmouseout="this.className='btn'"></form></td><td class="menuTD"><form method="post" action=""><input type="hidden" name="mid" value="9"><input type="submit" name="Help" value="Help" class="btn" onmouseover="this.className='btn btnhov'" onmouseout="this.className='btn'"></form></td></tr></table></div></div><div id="mainbody"><div id="leftmenu"><ul><li><form method="post" action=""><input type="hidden" name="mid" value="10"><input type="submit" name="Change Password" class="link_button_pass" value="Change Password"></form></li><li>Welcome: &quot;Motur&quot;01738023926</li></ul></div><div id="content"><span name="myspan" id="myspan"></span>

  
<div style="position: relative; width: 600px; height: 300px; z-index: 1; left: 10px; top: 15px" id="layer1"><div style="position: absolute; width: 370px; height: 287px; z-index: 1; left: 0px; top: 0px" id="layer2">
<link rel="stylesheet" href="templates/default/style.css" type="text/css">
<script language="JavaScript" type="text/javascript" src="templates/default/htmlform_jscript.js"></script>
<form name="form" action="javascript:get(document.getElementById('form'));" method="POST">
    <input type="hidden" name="HTMLForm_formname" value="form">
    
    
    <table align="center" size="450" border="0" class="list">

   
    <tr class="r2">
        <th class="left">
            <label id="label_send_to_no" for="send_to_no" class="HTMLForm-label">To</label>
        </th>
        <td class="left">
            <textarea id="send_to_no" name="send_to_no" class="HTMLForm-textarea" onkeypress="checkValidGPNumner(document.form.send_to_no)" onchange="checkValidGPNumner(document.form.send_to_no)" onkeyup="checkValidGPNumner(document.form.send_to_no)" wrap="soft" style="width:250px;height:50px"></textarea>  
                
        </td>    
  </tr>
  
   <tr class="r1">

        <th class="left">
            <label id="label_message" for="message" class="HTMLForm-label">Message</label>
        </th>
        <td class="left">
            <textarea id="message" name="message" class="HTMLForm-textarea" onkeypress="textCounter(document.form.message,document.form.counter_message,160)" onchange="textCounter(document.form.message,document.form.counter_message,160)" onkeyup="textCounter(document.form.message,document.form.counter_message,160)" wrap="soft" style="width:250px;height:130px"></textarea>
            
           <input type="text" id="counter_message" name="counter_message" size="5" value="" readonly="" class="HTMLForm-text"> <label id="label_char_remain" for="char_remain" class="HTMLForm-label">Character remained</label> 
        </td>

     </tr>
    
  <tr class="r2">
		 <td colspan="2" class="center">
            <input type="submit" id="submit" name="submit" value="Send" class="button_all_action">
            <input type="hidden" id="mid" name="mid" value="1">
            <input type="hidden" id="submit_sms" name="submit_sms" value="1">
        </td>
    </tr>
  

</table>
</form>
</div><div style="position: absolute; width: 200px; height: 286px; z-index: 1;  left: 380px;top: 0px" id="layer3"><div class="dhtmlgoodies_question" align="center"><font size="2">Phone Book</font></div><div class="dhtmlgoodies_answer"><div id="dhtmlgoodies_scrolldiv">
	<div id="scrolldiv_parentContainer">
	<div id="scrolldiv_content"></div>
	</div>
	<div id="scrolldiv_slider">
	<div id="scrolldiv_scrollUp"><img src="gfx/arrow_up.gif"></div>
	<div id="scrolldiv_scrollbar">
	<div id="scrolldiv_theScroll"><span></span></div>

	</div>
	<div id="scrolldiv_scrollDown"><img src="gfx/arrow_down.gif"></div>
	</div>
</div>
<script language="JavaScript" type="text/javascript">
	scrolldiv_setColor('#317082');	// Setting border color of the scrolling content
	setSliderBgColor('#E2EBED');	// Setting color of the slider div
	setContentBgColor('#FFFFFF');	// Setting color of the scrolling content
	setScrollButtonSpeed(1);	// Setting speed of scrolling when someone clicks on the arrow or the slider
	setScrollTimer(10);	// speed of 1 and timer of 5 is the same as speed of 2 and timer on 10 - what's the difference? 1 and 5 will make the scroll move a little smoother.
	scrolldiv_setWidth(250);	// Setting total width of scrolling div
	scrolldiv_setHeight(200);	// Setting total height of scrolling div
	scrolldiv_initScroll();	// Initialize javascript functions
</script></div></div></div><div class="xsnazzy"><b class="xtop"><b class="xb1"></b><b class="xb2 color_c"></b><b class="xb3 color_c"></b><b class="xb4 color_c"></b></b><div class="xboxcontent"><p><font size="2">Please enter valid GP number to send SMS in the following format: 017XXXXXXXX and separate each number by semicolon (;). You can directly enter number from the phone book by clicking the number. You will be able to send maximum 10 SMS(s) at a time and each SMS will be charged as BDT 0.50 excluding VAT.</font></p></div><b class="xbottom"><b class="xb4"></b><b class="xb3"></b><b class="xb2"></b><b class="xb1"></b></b></div></div><div id="rightcolumn"><div><img width="160" src="ad_image/about_grameenphone_small.jpg"></div><div> </div><div><img width="160" src="ad_image/Media_Centre_small.jpg"></div></div><br class="clear"><br class="clear"></div><div id="footer">© 2007 Grameenphone   |   <a href="terms_and_conditions.php" target="_blank">Terms and Conditions</a>   |   <a href="http://www.grameenphone.com/index.php?id=123" target="_blank">Contact</a></div></div></body></html>
