<html><head><title>GrameenPhone</title><script language="JavaScript" type="text/javascript" src="gfx/javascript_util.js"></script><link rel="stylesheet" href="gfx/layout.css" type="text/css"><link rel="stylesheet" href="gfx/style_util.css" type="text/css"><link rel="stylesheet" href="gfx/class.css" type="text/css"><meta http-equiv="CACHE-CONTROL" content="NO-CACHE"></head><body><div id="main"><div id="header"><img src="gfx/gp_white.jpg" alt="Grameenphone"><div id="input"><table border="0" cellspacing="0" cellpadding="0"><tr><td class="menuTD"><form method="post" action=""><input type="hidden" name="mid" value="1"><input type="submit" name="Login" value="Login" class="btnselect" onselect="this.className='btn'" onmouseover="this.className='btn btnhov'" onmouseout="this.className='btnselect'"></form></td><td class="menuTD"><form method="post" action=""><input type="hidden" name="mid" value="2"><input type="submit" name="Forget Password" value="Forgot Password?" class="btn" onselect="this.className='btn'" onmouseover="this.className='btn btnhov'" onmouseout="this.className='btn'"></form></td><td class="menuTD"><form method="post" action=""><input type="hidden" name="mid" value="500"><input type="submit" name="Help" value="Help" class="btn" onselect="this.className='btn'" onmouseover="this.className='btn btnhov'" onmouseout="this.className='btn'"></form></td></tr></table></div></div><div id="mainbody"><div id="leftmenu"><ul> </ul></div><div id="content"><table><tr><td>
<link rel="stylesheet" href="templates/default/style.css" type="text/css">
<script language="JavaScript" type="text/javascript" src="templates/default/htmlform_jscript.js"></script>
<form name="form" action="https://services.grameenphone.com/websms/index.php" method="POST">
    <input type="hidden" name="HTMLForm_formname" value="form">
    
    
    <table align="center" size="300" border="0" class="list">
	  <tr class="r1">
        <th colspan="3" class="left">
            <label id="label_login_title" for="login_title" class="HTMLForm-label">User Login</label>

        </th>
	</tr>
    <tr>
        <td align="right" valign="top">
            <label id="label_mobile_no" for="mobile_no" class="HTMLForm-label">Mobile Number</label>
        </td>
         
         <td>
            <input type="text" id="mobile_no" name="mobile_no" size="20" maxlength="11" value="" onkeypress="return checkNumberOnly(event)" class="HTMLForm-text"> 
        </td>

        
      </tr>
       <tr> 
        <td align="right" valign="top">
            <label id="label_password" for="password" class="HTMLForm-label">Password</label>
        </td>
        <td>
            <input type="password" id="password" name="password" value="" class="HTMLForm-password" size="20">
        </td>
   
        
       
    </tr>

   <tr>
           <td colspan="3" align="center">
        	    <input type="submit" id="submit" name="submit" value="Login" class="button_all_action">
            	<input type="hidden" id="submit_login" name="submit_login" value="1">
      	  </td>
    </tr>
</table>
</form>
</td><td valign="top"><div><div><font size="2"><a href="" onclick="slidedown_showHide('box1');return false;">How to Register?</a></font></div><div style="visibility: hidden; height: 0px;" class="dhtmlgoodies_contentBox" id="box1"><div style="top: -108px;" class="dhtmlgoodies_content" id="subBox1"><p>To register please go to Message option from your mobile phone with GP number, type <b>START WEBSMS</b> and send it to <b>9767</b> number. In the reply message you will get your password to log in to Web SMS Service.</p></div></div></div></td></tr></table><div class="xsnazzy"><b class="xtop"><b class="xb1"></b><b class="xb2 color_c"></b><b class="xb3 color_c"></b><b class="xb4 color_c"></b></b><div class="xboxcontent"><p><font size="2">Mobile Number: e.g. 017XXXXXXXX</font></p></div><b class="xbottom"><b class="xb4"></b><b class="xb3"></b><b class="xb2"></b><b class="xb1"></b></b></div></div><div id="rightcolumn"><div><img width="160" src="ad_image/thank_you_small.jpg"></div><div> </div><div><img width="160" src="ad_image/thank_you_small.jpg"></div></div><br class="clear"><br class="clear"></div><div id="footer">© 2007 Grameenphone   |   <a href="terms_and_conditions.php" target="_blank">Terms and Conditions</a>   |   <a href="http://www.grameenphone.com/index.php?id=123" target="_blank">Contact</a></div></div></body></html>
