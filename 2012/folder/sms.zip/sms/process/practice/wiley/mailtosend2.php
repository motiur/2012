<?php
mail("motiur_rahman@y7mail.com", "Hello World","Please let me in , i am starving ");
 ?>
