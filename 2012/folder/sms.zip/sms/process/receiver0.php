<?php

		$con=mysql_connect("localhost","motiur","hello012");
		if(!$con)
		{
		die('Could not connect: ' .mysql_error());
		}


		mysql_select_db("my_db",$con);


		$result = mysql_query("SELECT * FROM test");

		while($row = mysql_fetch_array($result))
		{
		echo $row['name']." ".$row['sender_number']." ".$row['receiver_number']." ".$row['message'];
		echo "<br/>";

		}
	mysql_close($con);
		 

?>
