function checkNumberOnly(evt) {
    evt = (evt) ? evt : window.event
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        status = "This field accepts numbers only."
        
        return false
    }
    status = ""
    return true
}
function textCounter(field,cntfield,maxlimit) {
		var strSMS = field.value.toString();
		var strSMSFilter = strSMS.replace(mikExp, ""); /* replace SP char with blank */
		if(field.value.length != strSMSFilter.length){
			field.value = strSMSFilter;
		}
		if (field.value.length > maxlimit){ 
		// if too long...trim it!
			field.value = field.value.substring(0, maxlimit);
		// otherwise, update 'characters left' counter
		}else{
			cntfield.value = maxlimit - field.value.length;
		}
}
