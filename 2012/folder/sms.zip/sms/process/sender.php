<html>

<head>
<h4>Please enter your username , number and password</h4>
</head>


<body>

<script language="JavaScript" type="text/javascript" src="htmlform_jscript.js"></script>

	<form action="sender2.php" method="post">
			<br/>
			Aloashbei User name:<input type="text" name="user_name"></input>
			<br/>
			<br/>
			Aloashbei Password: <input type="password" name="password" value="" size="20"/>
     	<br/>
			<br/>
  		Your Registered Number: <input type="text" name="sender_mobile_no" size="20" maxlength="11" value="" onkeypress="return checkNumberOnly(event)"/>
			<br/>
			<br/>
			Number you're sending: <input type="text" name="receiver_mobile_no" size="20" maxlength="11" value="" onkeypress="return checkNumberOnly(event)"/>
      <br/>
			<br/>
			Message:
			<br/>
			<br/>
			<textarea  name="message" maxlength = "180" wrap="soft" style="width: 250px; height: 130px; "></textarea>
			<br/>
			<br/>
			<input type="submit" name="submit" value="Send"/>
			<a href ="registration.php"><button type="button"> Not registered!</button></a>

	</form>

</body>

</html>

