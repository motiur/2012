<?

$con=mysql_connect("localhost","motiur","hello012");
	if(!$con)
	{
	die('Could not connect: ' .mysql_error());
	}


	mysql_select_db("my_db",$con);
 $sql = "INSERT INTO test (name, sender_number, receiver_number,message)
     VALUES('Friday', 01233, 345, 'its beautiful')";
$valid = mysql_query($sql, $con);	


	if($valid){echo "Success in insertion";}
	mysql_close($con);

?>
