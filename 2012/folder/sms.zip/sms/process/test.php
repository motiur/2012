<html>
<body>

<p> This is a text</p>
</body>
</html>

<?

	function poland()
	{
		echo "This is a function";
		echo "<br/>";	
	}
	//poland();

	echo "<input type = 'button' onclick = 'poland()' value = 'ball'/>";
?>
