<?

$con=mysql_connect("localhost","motiur","hello012");
	if(!$con)
	{
	die('Could not connect: ' .mysql_error());
	}

	echo "hhh";

	mysql_select_db("my_db",$con);
	
	$sql = "CREATE TABLE test
		(
		personID int NOT NULL AUTO_INCREMENT,
		PRIMARY KEY(personID),		
		name varchar(255),
		sender_number int,
		receiver_number int,
		message varchar(255)
		)";

	echo ",,,,";
	$valid = mysql_query($sql, $con);	


	if($valid){echo "Success in table creation";}
	mysql_close($con);


?>

