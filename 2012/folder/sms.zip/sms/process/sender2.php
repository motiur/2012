
<?

if (empty($_POST["user_name"])||empty($_POST["sender_mobile_no"])||empty($_POST["receiver_mobile_no"])||empty($_POST["password"])||empty($_POST["message"]))
	header("Location: http://localhost/grameenphone/aloashbei/process/sender.php");

?>

<html>

<body>
<pre>
      <?
				print_r($_POST);
	?>
</pre>
</body>
</html>
<?

$con=mysql_connect("localhost","motiur","hello012");
	if(!$con)
	{
	die('Could not connect: ' .mysql_error());
	}


	mysql_select_db("my_db",$con);
	
	$name = mysql_real_escape_string($_POST["user_name"]);
	$sender_number = (int)"88".$_POST["sender_mobile_no"];
	$receiver_number = (int)"88".$_POST["receiver_mobile_no"];
	$message = mysql_real_escape_string($_POST["message"]);
	

	echo $sender_number;
	echo "<br/>";
	echo $receiver_number;
	echo "<br/>";
	echo $message;
	echo "<br/>";
	echo $name;
	echo "<br/>";
		
	$sql = "INSERT INTO test (name, sender_number, receiver_number,message)
	     VALUES('$name', $sender_number, $receiver_number, '$message')";


	$success = mysql_query($sql, $con);	

	if ($success = 1) {echo "success in insertion";}
	mysql_close($con);


?>

<?php
 
$a['registrationID'] =htmlspecialchars($_POST['user_name']);  /*Your AloAshbei Username*/
$a['password'] =htmlspecialchars($_POST['password']);  /*Your Aloashbei Password*/
$a['sourceMsisdn'] =(int)"88".htmlspecialchars($_POST['sender_mobile_no']) ; /*Your registered number.*/
$a['destinationMsisdn'] =(int)"88".htmlspecialchars($_POST['receiver_mobile_no']); /*Number you are sending to.*/
$a['smsPort'] = 7424;
$a['msgType'] = 4;
$a['charge'] = 0.00 ;
$a['chargedParty'] =(int)"88".htmlspecialchars($_POST['sender_mobile_no']); /*Same as sourceMSISDN.*/
$a['contentArea'] = 'gpgp_psms';
$a['msgContent'] = htmlspecialchars($_POST['message']); /*The message being sent.*/
 
$soap_url='http://localhost/grameenphone/aloashbei/process/WebService_GP_ADP_BizTalk_SMS_Orchestrations.wsdl';
$soap = new SoapClient($soap_url);

$response=$soap->sendSMS( array ("SendSMSRequest" => $a) ); 
 
echo '<pre>';
print_r($response);
echo '</pre>';

?>
