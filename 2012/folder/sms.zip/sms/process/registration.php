<html>


<body>
<a href="https://www.aloashbei.com.bd/user/register/">Username and email</a>
<br/>
<p>Follow the instruction given in your email</p>
<br/>
<p>After logging in to your profile  , click edit profile<br/> and add your phone number</p>


</body>

</html>
